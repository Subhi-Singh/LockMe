package com.simplilearn.lockme.application;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Scanner;

import com.simplilearn.lockme.model.UserCredentials;
import com.simplilearn.lockme.model.Users;

public class Authentication {
	//input data
	private static Scanner keyboard;
	private static Scanner input;
	
	
	
	
	public static void main(String[] args) {
		initApp();
		welcomeScreen();
		userDetails();
		//signInOptions();
		//loginTask();
	}
	public static void userDetails() {
		System.out.println("==============================================");
		System.out.println("1 . View Files ");
		System.out.println("2 . Other Details ");
		System.out.println("3 . ExitApplication ");
		int option = keyboard.nextInt();
		switch(option) {
			case 1 : 
				viewFiles();
				break;
			case 2 :
				fileDetails();
				break;
			case 3 :
				exitApplication();
				break;
			default :
				System.out.println("Please select 1 Or 2");
				break;
		}
		keyboard.close();
		input.close();
	}
	
	public static void viewFiles()
	{
		 File directory = new File(".");
		File[] files = directory.listFiles();
		Arrays.sort(files, (a, b) -> a.getName().compareTo(b.getName()));
		for(File file : files)
		{
			 if (file.getName().endsWith(".txt"))
			   {
			       System.out.println(file.getName());
			   }
		}
		userDetails();
	}
	
	public static void fileDetails()
	{
		System.out.println("==============================================");
		System.out.println("1 . ADD FILE ");
		System.out.println("2 . DELETE FILE ");
		System.out.println("3 . SEARCH FILE ");
		System.out.println("4 . RETURN TO PREVIOUS MENU ");
		int option = keyboard.nextInt();
		switch(option) {
			case 1 : 
				addFile();
				break;
			case 2 :
				deleteFile();
				break;
			case 3 :
				searchFile();
				break;
			case 4 :
				userDetails();
				break;
			default :
				System.out.println("Please select any one option from above.");
				break;
		}
		keyboard.close();
		input.close();
	}
	
	public static void addFile()
	{
		try
		{
			System.out.println("PLEASE ENTER THE FILE NAME : ");
			String fileName = keyboard.next();
			File userFile = new File(fileName+".txt");
			if(userFile.exists())
			{
				
				System.out.println("-------FILE ALREADY EXISTS!--------");
				fileDetails();
			}
			else
			{
				userFile.createNewFile();
				System.out.println("YOUR FILE HAS BEEN CREATED!");
				fileDetails();
			}
			
			
		//	lockerOutput.println(userCredentials.getLoggedInUser());
			
		}catch (IOException e) {
			System.out.println("ERROR CREATING FILE  !!!!!!!!!");
			fileDetails();
		}
	}
	
	public static void deleteFile()
	{
		System.out.println("PLEASE ENTER THE FILE NAME TO BE DELETED : ");
		String fileName = keyboard.next();
		File userFile = new File(fileName+".txt");
		if(userFile.delete())
		{
			 System.out.println("File deleted successfully");
			 fileDetails();
		}
		 else
	    {
	         System.out.println("Failed to delete the file");
	         fileDetails();
	    }
	}
	
	public static void searchFile()
	{
		System.out.println("PLEASE ENTER THE FILE NAME TO BE SEARCHED : ");
		String fileName = keyboard.next();
		File userFile = new File(fileName+".txt");
		if(userFile.exists())
		{
			
			System.out.println("-------FILE FOUND!--------");
			fileDetails();
		}
		else
		{
			System.out.println("-------FILE NOT FOUND!--------");
			fileDetails();
		}
	}
	
	
	public static void exitApplication()
	{
		System.out.println("----------------APPLICATION CLOSED-------------");
	}


	
	
	public static void welcomeScreen() {
		System.out.println("==========================================");
		System.out.println("*					*");
		System.out.println("*   Welcome To LockMe.com		*");
		System.out.println("*   Your Personal File Locker	*");
		System.out.println("*					*");
		System.out.println("==========================================");
		System.out.println("===================SUBHI SINGH=======================");
		
	}
	//store credentails
	
	
	public static void initApp() {

		File  dbFile = new File("database.txt");
		File  lockerFile = new File("locker-file.txt");
		
		try {
			//read data from db file
			input = new Scanner(dbFile);
			
			
			
			//read data from keyboard
			keyboard = new Scanner(System.in);
			
			
			
			
		} catch (IOException e) {
			System.out.println("404 : File Not Found ");
		}
		
	}

}
